package test;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Q2 {


	

	@Test(dataProvider = "testdata")
	public void LoanCalc(String amount, String tenure, String loanAmt) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "D:\\CWBTest\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.commbank.com.au/digital/home-buying/calculator/home-loan-repayments");
		driver.manage().window().maximize();
		driver.findElement(By.id("amount")).clear();
		driver.findElement(By.id("amount")).sendKeys(amount);
		Thread.sleep(2000);
		
		int tenureInt = Integer.parseInt(tenure) + 1;
		driver.findElement(By.id("term")).clear();
		driver.findElement(By.id("term")).sendKeys(String.valueOf(tenureInt));
		/*
		 * JavascriptExecutor myExecutor = ((JavascriptExecutor) driver);
		 * myExecutor.executeScript("arguments[0].value='"+String.valueOf(tenureInt)+
		 * "';", driver.findElement(By.id("term")));
		 */
		Thread.sleep(2000);
		
		Select listbox = new Select(driver.findElement(By.id("interestOnly")));
		listbox.selectByIndex(Integer.parseInt(tenure));
		Thread.sleep(2000);
			
	
		
		driver.findElement(By.id("submit")).click();
		Thread.sleep(5000);
		String actTotalamt = driver.findElement(By.xpath("//*[@data-tid='total-repayment']")).getText().replace("$", "")
				.replace(",", "");
		int actTotalIntrest = Integer.parseInt(driver.findElement(By.xpath("//*[@data-tid='total-interest']")).getText()
				.replace("$", "").replace(",", ""));
		int expTotalintrest = Integer.parseInt(loanAmt) - Integer.parseInt(amount);

		if (actTotalIntrest == expTotalintrest && actTotalamt.contains(loanAmt)) {
			System.out.println("loan amount & interest are matching as expected for dataset: " + tenure);
		} else {
			System.out.println("loan amount & interest are not matching as expected for dataset: " + tenure);
		}

		Assert.assertEquals(actTotalIntrest, expTotalintrest);
		System.out.println("Actual: " + actTotalIntrest + "   Exp: " + expTotalintrest);
		 driver.quit(); 
	}

	
	  @AfterTest 
	  void ProgramTermination() {
		 
		  }
	 

	@DataProvider(name = "testdata")
	public Object[][] testDataExample() {
		ReadExcelFile configuration = new ReadExcelFile("D:\\CWBTest\\src\\resource\\TestData.xls");
		int rows = configuration.getRowCount(0);
		Object[][] signin_credentials = new Object[rows-1][3];

		for (int i = 1; i < rows; i++) {
			signin_credentials[i - 1][0] = configuration.getData(i, 1);
			signin_credentials[i - 1][1] = configuration.getData(i, 2);
			signin_credentials[i - 1][2] = configuration.getData(i, 3);

		}
		return signin_credentials;
	}

	public void enterTxt() {

	}
}
