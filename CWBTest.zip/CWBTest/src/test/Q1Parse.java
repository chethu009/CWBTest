package test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.opencsv.CSVWriter;

public class Q1Parse {
	static String filePath = "D:\\CWBTest\\src\\resource\\";

	public static void main(String[] args) throws IOException, ParseException {
		// TODO Auto-generated method stub

		BufferedReader br = new BufferedReader(new FileReader(filePath + "q1.TEST_DATA"));
		try {
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();

			while (line != null) {
				sb.append(line);
				sb.append(System.lineSeparator());
				line = br.readLine();
			}
			br.close();

			String[] fullFile = sb.toString().split("SZ");
			String[] transaction = Arrays.stream(fullFile).filter(value -> value != null && value.length() > 0)
					.toArray(size -> new String[size]);
			for (int k = 0; k < transaction.length; k++) {
				HashMap<String, String> hp = new HashMap<String, String>();
				System.out.println("************************transaction " + (k+1) + "*************************");
				String[] everything = transaction[k].split(" ");
				// System.out.println(everything);
				String[] removedNull = Arrays.stream(everything).filter(value -> value != null && value.length() > 0)
						.toArray(size -> new String[size]);
				/*
				 * for (int i = 0; i < removedNull.length; i++) {
				 * System.out.println(removedNull[i]); }
				 */
				int j = 0;
				int i = 0;

				while (i < removedNull.length) {
					// System.out.println(removedNull[i]);
					String tmpkey = removedNull[i];
					i++;
					if (tmpkey.contains("_")) {
						for (j = i; j < removedNull.length; j++) {
							String tmpvalue = removedNull[j];
							// System.out.println(tmpvalue);
							if (tmpvalue.contains("_")) {
								i = j;
								break;
							}
							if (tmpvalue.startsWith("\"")) {
								tmpvalue = tmpvalue.replace("]", "").replace("\"", "").trim();
								System.out.println("Key=" + tmpkey + "Value=" + tmpvalue);
								i = j;
								hp.put(tmpkey, tmpvalue);
								
								break;
							}
						}

					}

				}
				//System.out.println("Hashmap: ###############" + hp);
				write2Excell(hp,k+1);
				write2CSV(hp,k+1);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	
	public static void write2CSV(HashMap<String, String> hp, int t) {
		 File file = new File(filePath+ "transaction" + t + ".csv");
		    try {
		        // create FileWriter object with file as parameter
		        FileWriter outputfile = new FileWriter(file);
		  
		        // create CSVWriter object filewriter object as parameter
		        CSVWriter writer = new CSVWriter(outputfile);
		  
		        // adding header to csv
		        String[] header = { "Name", "Value" };
		        writer.writeNext(header);
		    	int i=1;
				for (String name : hp.keySet()) {
		        // add data to csv
		        String[] data1 = { name, hp.get(name) };
		        writer.writeNext(data1);
		      
		        i++;
				}
		        // closing writer connection
		        writer.close();
		        
		        
		        
		    }
		    catch (IOException e) {
		        // TODO Auto-generated catch block
		        e.printStackTrace();
		    }
	}
	public static void write2Excell(HashMap<String, String> hp, int t) {
		try {
			
			// declare file name to be create
			String filename = filePath + "transaction" + t + ".xls";
			// creating an instance of HSSFWorkbook class
			HSSFWorkbook workbook = new HSSFWorkbook();
			// invoking creatSheet() method and passing the name of the sheet to be created
			HSSFSheet sheet = workbook.createSheet("test");
			// creating the 0th row using the createRow() method
			HSSFRow rowhead = sheet.createRow((short) 0);
			// creating cell by using the createCell() method and setting the values to the
			// cell by using the setCellValue() method
			rowhead.createCell(0).setCellValue("Name");
			rowhead.createCell(1).setCellValue("Value");
			int i=1;
			for (String name : hp.keySet()) {
				// creating the 1st row
				HSSFRow row = sheet.createRow((short) i);
				// inserting data in the first row
				row.createCell(0).setCellValue(name);
				row.createCell(1).setCellValue(hp.get(name));
				i++;
			}
			FileOutputStream fileOut = new FileOutputStream(filename);
			workbook.write(fileOut);
			// closing the Stream
			fileOut.close();
			// closing the workbook
			workbook.close();
			// prints the message on the console
			System.out.println("Excel file has been generated successfully.");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
